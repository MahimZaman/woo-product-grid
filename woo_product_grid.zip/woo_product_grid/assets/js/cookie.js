document.addEventListener("DOMContentLoaded", () => {
  // Check if the popup should be shown
  if (document.cookie.indexOf("wpg_close_popup") === -1) {
    // Show the popup
    const closePopup = document.querySelector(".wpg_close_popup");
    const navPopup = document.querySelector(".wpg_navigate_popup");

    if (navPopup) {
      navPopup.classList.add("active");

      // Close pop-up when close button is clicked
      closePopup.addEventListener("click", () => {
        navPopup.classList.remove("active");
        var expires = new Date();
        expires.setTime(expires.getTime() + 60 * 864000);
        document.cookie =
          "wpg_close_popup=true;expires=" + expires.toUTCString() + ";path=/";
      });
    }
  }
});
