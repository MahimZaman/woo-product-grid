$ = jQuery;

$(document).ready(function () {
  $(".wpg_filter_selects").on("click", function () {
    $(".wpg_filter_option").css("display", "block");
    $(".wpg_clear_filter").css("display", "flex");
  });

  $(document).on("click", function (e) {
    const filterInput = document.querySelector(".wpg_filter_selects");
    const filterOptions = document.querySelector(".wpg_filter_option");
    const filterPlaceholder = document.querySelector(".wpg_filter_placeholder");
    const filters = document.querySelectorAll(".wpg_filter_option li");
    if (filterInput) {
      if (filterInput.contains(e.target) || filterOptions.contains(e.target)) {
        $(".wpg_filter_option").css("display", "block");
      } else {
        $(".wpg_filter_option").css("display", "none");
        if (document.querySelectorAll(".selected_filter").length < 1) {
          $(".wpg_clear_filter").css("display", "none");
        }
      }
    }
  });

  $(".wpg_filter_option li").on("click", function () {
    $(".wpg_filter_placeholder").css("display", "none");
    const selectFilter = document.createElement("span");
    selectFilter.className = "selected_filter";
    selectFilter.id = $(this).data("term_id");
    selectFilter.innerHTML = `<span class="deselect_filter" data-close_id = ${$(
      this
    ).data("term_id")}><i class="fa-solid fa-times"></i></span>
    ${$(this).text()} 
    `;
    $(".wpg_filter_selects").append(selectFilter);
    $(this).css("pointer-events", "none");

    // Deleter particular Filter
    $(".deselect_filter").on("click", function () {
      $("#" + $(this).data("close_id")).detach();

      $(
        ".wpg_filter_option li[data-term_id =" + $(this).data("close_id") + "]"
      ).css("pointer-events", "all");

      if ($(".selected_filter").length == 0) {
        $(".wpg_filter_placeholder").css("display", "block");
      }

      wpg_filter_ajax();
    });

    // Clear All Filters
    $(".wpg_clear_filter").on("click", function () {
      $(".selected_filter").detach();

      $(".wpg_filter_option li").css("pointer-events", "all");

      $(".wpg_filter_placeholder").css("display", "block");

      wpg_filter_ajax();
    });

    //Run Ajax ;
    wpg_filter_ajax();
  });

  // Ajax function to filter posts ;
  function wpg_filter_ajax() {
    let taxArr = [];
    const selectedFields = document.querySelectorAll(".selected_filter");
    selectedFields.forEach((filter) => {
      taxArr.push(filter.id);
    });

    $(".wpg_filter_spinner").css("display", "flex");

    // Shop Page AJAX
    if ($("body").hasClass("wpg-shop-page")) {
      $.ajax({
        type: "POST",
        url: filter.admin_url,
        data: {
          action: "wpg_filter_action",
          terms: taxArr,
        },
        success: function (response) {
          $(".wpg-shop-page .wpg_shop_term_container").html(response);
          $(".wpg_filter_spinner").css("display", "none");
          $(document).trigger("wpg_filter_loaded");
        },
        error: function (error) {
          console.log(error.responseText);
        },
      });
    }

    // Category Page AJAX
    if ($("body").hasClass("wpg-category-page")) {
      $.ajax({
        type: "POST",
        url: filter.admin_url,
        data: {
          action: "wpg_filter_action_cat",
          terms: taxArr,
          parent: $(".wpg_filter_parent").data("parent_id"),
        },
        success: function (response) {
          $(".wpg-category-page .wpg-subcat-container").html(response);
          $(".wpg_filter_spinner").css("display", "none");
          $(document).trigger("wpg_filter_loaded");
        },
        error: function (error) {
          console.log(error.responseText);
        },
      });
    }

    // Sub-cat FIlter Ajax
    if ($("body").hasClass("wpg-sub-category-page")) {
      $.ajax({
        type: "POST",
        url: filter.admin_url,
        data: {
          action: "wpg_filter_action_subcat",
          terms: taxArr,
          parent: $(".wpg_filter_option").data("parent_id"),
          page_sub_id: $(".wpg_filter_option").data("id_subcat"),
        },
        success: function (response) {
          $(".wpg-sub-category-page .wpg-other-subcats").html(response);
          $(".wpg_filter_spinner").css("display", "none");
          $(document).trigger("wpg_filter_loaded");
        },
        error: function (error) {
          console.log(error.responseText);
        },
      });
    }
  }
});
