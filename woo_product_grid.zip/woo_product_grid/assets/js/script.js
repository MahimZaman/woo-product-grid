// Here $=jQuery used because $ sign will conflict with wordpress codes. So it only supports jQuery instead.
$ = jQuery;

$(document).on("wpg_filter_loaded", function () {
  ajaxLoadMore();
});

$(document).ready(function () {
  ajaxLoadMore();
});

function ajaxLoadMore() {
  const loadMore = $(".wpg_loadmore_btn");
  $(loadMore).on("click", function () {
    var index = $(loadMore).index(this);

    var page = parseInt(loadMore[index].dataset.page_no) + 1;
    var gridContainer = $(".wpg_product_items")[index];
    var postCount = $(".wpg_post_count .wpg_counter .wpg_post_showing")[index];
    var showingPost = parseInt(postCount.textContent);
    var total_pages = $(".wpg_query_grid")[index].dataset.total_pages;
    var total_posts = $(".wpg_query_grid")[index].dataset.total_posts;
    var catId = $(".wpg_query_grid")[index].dataset.cat_id;

    var nextPageCount = parseInt(total_posts) - showingPost;

    if (nextPageCount > parseInt(query_ajax.postPerPage)) {
      nextPageCount = showingPost + parseInt(query_ajax.postPerPage);
    } else {
      nextPageCount = nextPageCount + showingPost;
    }

    var loadProgress = (nextPageCount / parseInt(total_posts)) * 100 + "%";

    $(".wpg_loader")[index].style.display = "block";

    // Ajax Calls
    $.ajax({
      type: "POST",
      url: query_ajax.admin_url,
      data: {
        action: "wpg_handle_load_more",
        page: page,
        total_pages: total_pages,
        total_posts: total_posts,
        cat_id: catId,
      },
      success: function (response) {
        loadMore[index].dataset.page_no = page;
        if (nextPageCount == parseInt(total_posts)) {
          loadMore[index].remove();
        }
        $(".wpg_load_bar")[index].style.width = loadProgress;
        $(".wpg_load_bar")[index].style.transition = "all 0.4s ease";
        $(gridContainer).append(response);
        $(postCount).html(nextPageCount);
        $(".wpg_loader")[index].style.display = "none";
      },
      error: function (error) {
        console.log(error.responseText);
      },
    });
  });
}
