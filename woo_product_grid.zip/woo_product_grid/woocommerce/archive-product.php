<?php
    get_header('shop');

    if(wp_is_mobile()){
        $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
    }
    elseif(wp_is_mobile() && preg_match( '/iPad/', $_SERVER['HTTP_USER_AGENT'] )){
        $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
    }
    else{
        $wpg_posts_per_page = get_option('wpg_post_perpage');
    }
    $wpg_loadmore_text = get_option('wpg_loadmore_text');
    if(function_exists('icl_register_string')){
        $translate = 'icl_t';
    }
    else{
        $translate = '__';
    }
?>

<section class="wpg_breadcrumb container py-2">
    <a href="<?php echo site_url();?>"
        class="wpg-bc_site_title"><?php echo $translate('Gothia Medical AB', 'wpg-plugin');?></a> /
    <span class="wpg-bc_product_page">
        <a
            href="<?php echo get_permalink(wc_get_page_id( 'shop' ));?>"><?php echo $translate('Produkter', 'wpg-plugin');?></a>
        <div class="wpg_navigate_popup">
            <?php echo $translate('Did you know you can navigate here!')?>
            <div class="wpg_close_popup"><i class="fa-regular fa-circle-xmark"></i></div>
        </div>
    </span>
</section>

<?php
if(get_option('wpg_shop_slider')):?>
<section class="container-fluid wpg_hero_slider">
    <?php echo do_shortcode('[rev_slider alias="'.get_option( 'wpg_shop_slider' ).'"][/rev_slider]');?>
</section>
<?php
endif;
?>

<section class="wpg_shoppage_details">
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-9 pt-lg-5 pt-3">
                <h1 class="wpg_shoppage_title">
                    <?php echo $translate(get_option('wpg_shop_title'), 'wpg-plugin');?>
                </h1>
                <p class="wpg_shoppage_desc">
                    <?php echo $translate(get_option('wpg_shop_desc'), 'wpg-plugin'); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<?php
$wpg_uncategorized = get_term_by( 'slug', 'uncategorized', 'product_cat' );
$wpg_product_categories = get_terms(array(
    'taxonomy' => 'product_cat',
    'hide_empty' => true,
    'parent' => 0,
    'exclude_tree' => array( $wpg_uncategorized -> term_id )
));
?>
<section class="wpg_subcats pb-3 pb-lg-5">
    <div class="container wpg_filter">
        <div class="row">
            <div class="col-12 justify-content-end d-flex">
                <div class="wpg_filter_inner position-absolute">
                    <div class="wpg_filter_spinner">
                        <div class="lds-spinner">
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                            <div></div>
                        </div>
                    </div>
                    <span class="wpg_clear_filter position-absolute"><i class="fa-solid fa-times"></i></span>
                    <input class="form-control" type="hidden" name="wpg_filter_input" id="wpg_filter_input" value="" />
                    <span class="wpg_filter_selects form-control">
                        <span class="wpg_filter_placeholder">
                            <?php echo $translate('Filter by category', 'wpg-plugin');?>
                        </span>
                    </span>
                    <ul class="wpg_filter_option">
                        <?php foreach($wpg_product_categories as $wpg_category):
                        $wpg_subcat_arr = get_term_children( $wpg_category -> term_id, 'product_cat' );
                        ?>
                        <h4><?php echo $wpg_category -> name;?></h4>
                        <?php foreach($wpg_subcat_arr as $id):
                $wpg_subcat_detail = get_term( $id , 'product_cat' );
                            if($wpg_subcat_detail -> count > 0):
                ?>
                        <li data-term_id="<?php echo $id;?>">
                            <?php echo $wpg_subcat_detail -> name;?></li>
                        <?php 
                        endif;
                endforeach ;
                endforeach;?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="wpg_shop_term_container">
        <?php foreach($wpg_product_categories as $wpg_category):
         ?>
        <div class="container mt-3">
            <div class="row">
                <div class="col-12">
                    <h2 class="wpg_cat_title">
                        <?php echo $translate($wpg_category-> name, 'wpg-plugin');?>
                    </h2>
                </div>
            </div>
        </div>
        <?php     
        $wpg_subcat_arr = get_term_children( $wpg_category -> term_id, 'product_cat' );   ?>
        <div class="wpg_subcat_container">
            <?php
        foreach($wpg_subcat_arr as $id):
        $wpg_subcat_detail = get_term( $id , 'product_cat' );
        $arg = array(
            'post_type' => 'product',
            'posts_per_page' => $wpg_posts_per_page,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $id,
                    'include_children' => true
                ),
            ),
            'meta_key' => 'wpg_post_position',
            'orderby' => array(
                'meta_value_num' => 'ASC',
                'date' => 'ASC'
            ), 
        );
        
        $query = new WP_Query( $arg );

        if( $query -> have_posts() ):
        ?>
            <div class="pt-3 container position-relative wpg_query_grid" data-cat_id=<?php echo $id;?>
                data-total_posts="<?php echo $query -> found_posts; ?>"
                data-total_pages="<?php echo $query -> max_num_pages ?>">


                <div class="row">
                    <div class="col-12">
                        <h3 class="wpg_subcat_title">
                            <?php echo $translate($wpg_subcat_detail -> name, 'wpg-plugin') ;?>
                        </h3>
                        <div class="wpg_separator"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="d-flex flex-wrap col-12 wpg_product_items">
                        <?php 
                if($query -> have_posts()):
                    while($query -> have_posts()):
                        $query-> the_post();
                        $product = wc_get_product( get_the_ID() );
                        $default_img = wp_get_attachment_url( $product -> get_image_id() ) ;
                        $img_extra = get_field('wpg_product_img_extra');
                        $name_extra = get_field('wpg_product_name_extra');
                        $btn_text = get_field('wpg_product_btn_text');
                        $text_extra = get_field('wpg_product_text_extra');
            ?>
                        <div class="card mb-4 wpg_product_item px-0">
                            <a href="<?php echo the_permalink();?>" class="wpg_card_overlay"></a>
                            <?php 
                    if(isset($img_extra['url'])):
                ?>
                            <img src="<?php echo $img_extra['url'];?>" class="card-img-top"
                                alt="<?php echo $img_extra['alt'];?>">
                            <?php
                    else:
                ?>
                            <img src="<?php echo $default_img;?>" class="card-img-top" alt="<?php echo the_title();?>">
                            <?php
                    endif;
                ?>

                            <div class="card-body text-center px-0 d-flex flex-column justify-content-between">
                                <div class="card-content">
                                    <?php
                        if($name_extra != ''):
                    ?>
                                    <h5 class="card-title  px-3"><?php echo $translate($name_extra, 'wpg-plugin');?>
                                    </h5>
                                    <?php
                        else:
                    ?>
                                    <p class="card-title px-3">
                                        <?php echo $translate($product -> get_name(), 'wpg-plugin');?>
                                    </p>
                                    <?php
                        endif;
                    ?>
                                    <?php 
                        if($text_extra != ''):
                    ?>
                                    <p class="card-text px-3"><?php echo $translate($text_extra, 'wpg-plugin');?></p>
                                    <?php 
                        else:
                    ?>
                                    <span class="d-block card-text px-3">
                                        <?php echo do_shortcode($product -> get_short_description());?>
                                    </span>
                                    <?php
                        endif;
                    ?>
                                </div>
                                <div class="card-footer text-center">
                                    <a href="<?php echo the_permalink();?>" class="btn btn-primary stretched-link mt-2">
                                        <?php if($btn_text != ''):
                            echo $btn_text;
                        else:
                            echo $translate('Visa produkt', 'wpg-plugin');
                        endif;
                        ?>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <?php
                endwhile;
                wp_reset_postdata();
            else:
                echo '<p class="">No posts found</p>';
            endif;
            ?>
                    </div>
                </div>
            </div>

            <div class="container">
                <div class="row align-items-center justify-content-center">
                    <div class="wpg_load_more d-flex align-items-center justify-content-center flex-column">
                        <div class="wpg_post_count d-flex align-items-center justify-content-center flex-column">
                            <div class="wpg_loader" style='display: none'></div>
                            <span class="wpg_counter"><?php echo $translate('Showing', 'wpg-plugin')?> <span
                                    class="wpg_post_showing"><?php echo $query -> post_count;?></span>
                                <?php echo $translate('of', 'wpg-plugin')?> <span
                                    class="wpg_available_post"><?php echo $query -> found_posts?></span>
                                <?php echo $translate('results', 'wpg-plugin')?></span>
                            <span class="wpg_progress_bar">
                                <?php 
                            if(intval($query -> found_posts) <= 0){
                                $wpg_loadbar_width = 0;
                            }
                            else{
                                $wpg_loadbar_width = (intval($wpg_posts_per_page) / intval($query -> found_posts)) * 100 . '%';
                            }
                        ?>
                                <span class="wpg_load_bar" style="width: <?php echo $wpg_loadbar_width ;?> "></span>
                            </span>
                        </div>
                        <?php
                   if(intval($query -> found_posts) <= intval($wpg_posts_per_page)){
                    $display = 'display: none';
                  } 
                  else{
                    $display = '';
                  }
                ?>
                        <button class="px-5 btn-lg btn btn-primary wpg_loadmore_btn" style="<?php echo $display;?>"
                            data-page_no="1"><?php echo $wpg_loadmore_text == '' ? $translate('Load More', 'wpg-plugin'): $translate($wpg_loadmore_text, 'wpg-plugin');?></button>

                    </div>
                </div>
            </div>
            <?php 
    endif;
        endforeach;?>
        </div>
        <?php
endforeach;?>
    </div>
</section>

<?php  
get_footer('shop');
?>