<?php
/*
 * Plugin Name:       Woo Product Grid
 * Plugin URI:        https://example.com/plugins/the-basics/
 * Description:       Lorem ipsum dolor, sit amet consectetur adipisicing elit. Porro, eveniet!
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Author
 * Author URI:        https://author.example.com/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wpg-plugin
 * Domain Path:       /languages
 */

 if( !defined( 'ABSPATH' ) ){
    exit;
 }

 define('WPG_DIR', plugin_dir_path(__FILE__));
 define('WPG_URL', plugin_dir_url(__FILE__));

 include_once( WPG_DIR . 'inc/wpg_woo_activation_check.php' );

 class Woo_Product_Grid{
    
    function __construct(){
        // Front-End Scripts
        add_action('wp_enqueue_scripts', array( $this, 'wpg_frontend_scripts' ));

        // Admin Scripts
        add_action('admin_enqueue_scripts', array( $this, 'wpg_admin_scripts' ));
        
        // @Hooked - admin_menu
        add_action( 'admin_menu', array( $this, 'wpg_menu_page_settings' ) );

        // @Hooked - woocommerce_locate_template;
        add_filter( 'woocommerce_locate_template', array( $this, 'wpg_woo_template_repository'), 10, 3 );
        add_filter( 'template_include', array($this, 'wpg_product_cat_template'), 99 );

        // Ajax action 
        add_action('wp_ajax_wpg_handle_load_more', array($this, 'wpg_handle_load_more'));
        add_action('wp_ajax_nopriv_wpg_handle_load_more', array($this, 'wpg_handle_load_more'));

        // Ajax filter action 
        add_action('wp_ajax_wpg_filter_action', array($this, 'wpg_filter_action'));
        add_action('wp_ajax_nopriv_wpg_filter_action', array($this, 'wpg_filter_action'));
        add_action('wp_ajax_wpg_filter_action_cat', array($this, 'wpg_filter_action_cat'));
        add_action('wp_ajax_nopriv_wpg_filter_action_cat', array($this, 'wpg_filter_action_cat'));
        add_action('wp_ajax_wpg_filter_action_subcat', array($this, 'wpg_filter_action_subcat'));
        add_action('wp_ajax_nopriv_wpg_filter_action_subcat', array($this, 'wpg_filter_action_subcat'));
        
        // Save Settings Action
        add_action( 'admin_post_wpg_plugin_action', array($this, 'wpg_save_settings') );

        // Dynamic CSS
        add_action('wp_head', array($this, 'wpg_dynamic_css'));

        // @Hooked - admin_init
        add_action('admin_init', array( $this, 'wpg_default_settings' ));

        // @Hooked - plugins_loaded 
        add_action('plugins_loaded', array( $this, 'wpg_text_domain' ));
        add_action('plugins_loaded', array( $this, 'wpg_load_wpml' ));

        // @filter - body_class
        add_filter( 'body_class', array( $this, 'wpg_body_classes' ) );

        
    }

    function wpg_text_domain(){
        // Loading language text domain
        load_plugin_textdomain( 'wpg-plugin', false, WPG_DIR . 'language' );
    }

    function wpg_load_wpml(){
        if(!in_array('sitepress-multilingual-cms/sitepress.php', apply_filters( 'active_plugins', get_option('active_plugins') )) ){
            add_action('admin_notices', function(){
                echo '<div class="notice notice-warning is-dismissible">
                    <p>Install & Activate WPML for string translation</p>
                </div>';
            });
        }
    }

    function wpg_dynamic_css(){
        // Dynamic CSS
        include_once(WPG_DIR . 'inc/wpg_dynamic_css.php');
    }

    function wpg_frontend_scripts(){
        // CSS

            // Bootstrap CSS
            wp_enqueue_style( 'wpg_bootstrap_css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css', array(), time() );

            // Fontawesome CSS
            wp_enqueue_style( 'wpg_fontawesome_css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css', array(), time() );

            // Plugin frontend CSS
            wp_enqueue_style( 'wpg_style_css', WPG_URL . '/assets/css/style.css', array(), time() );

        //JavaScript Enqueue List:-

            // Check if jQuery is connected to the site if not then connect jQuery.
            if(!wp_script_is( 'jquery', 'done' )){
                wp_enqueue_script( 'jquery');
            }

            // Bootstrap JS
            wp_enqueue_script( 'wpg_bootstrap_js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js' , array(), time(), true );

            // Plugin Frontend JS
            wp_enqueue_script( 'wpg_script_js', WPG_URL . '/assets/js/script.js' , array(), time(), true );

            // Cookie JS
            wp_enqueue_script( 'wpg_cookie_js', WPG_URL . '/assets/js/cookie.js', array(), time(), true );

            // Filter JS
            wp_enqueue_script( 'wpg_filter_js', WPG_URL . '/assets/js/filter.js', array(), time(), true );

            //Localize Script

            if(wp_is_mobile()){
                $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
            }
            elseif(wp_is_mobile() && preg_match( '/iPad/', $_SERVER['HTTP_USER_AGENT'] )){
                $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
            }
            else{
                $wpg_posts_per_page = get_option('wpg_post_perpage');
            }

            // Passing ajax url to plugin js file.
            wp_localize_script( 'wpg_script_js', 'query_ajax', array(
                'admin_url' => admin_url('admin-ajax.php'),
                'postPerPage' => $wpg_posts_per_page,
            ) );

            // Passing ajax url to plugin js file.
            wp_localize_script( 'wpg_filter_js', 'filter', array(
                'admin_url' => admin_url('admin-ajax.php'),
            ) );
    }

    function wpg_admin_scripts(){
        if(isset($_GET['page'])){
            if($_GET['page'] == 'wpg-settings'){
                // CSS
                wp_enqueue_style( 'wpg_bootstrap_css', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css', array(), time() );
                // Fontawesome CSS
                wp_enqueue_style( 'wpg_fontawesome_css', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css', array(), time() );
            
                wp_enqueue_style( 'wpg_style_css', WPG_URL . '/assets/css/admin-style.css', array(), time() );
                //JS
                wp_enqueue_script( 'wpg_bootstrap_js', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js' , array(), time(), true );
                wp_enqueue_script( 'wpg_admin_script_js', WPG_URL . '/assets/js/admin-script.js' , array(), time(), true );
            }
        }

    }

    function wpg_woo_template_repository( $template, $template_name, $template_path ) {

        $template_directory = trailingslashit( plugin_dir_path( __FILE__ ) ) . 'woocommerce/';
        $path = $template_directory . $template_name;
    
        return file_exists( $path ) ? $path : $template;
    
    }

    function wpg_product_cat_template($template){
        if ( is_tax( 'product_cat') ) {
            $term = get_term(get_queried_object_id(), 'product_cat');
            // Check if parent has a term
            $ancestors = get_ancestors( $term -> term_id, 'product_cat' ) ;
            if( !empty( $ancestors ) ){
                $new_template = plugin_dir_path( __FILE__ ) . 'woocommerce/wpg_templates/wpg_subcat_archive.php';
                if ( file_exists( $new_template ) ) {
                    return $new_template ;
                }
            }
            else{
                $new_template = plugin_dir_path( __FILE__ ) . 'woocommerce/wpg_templates/wpg_category_archive.php';
                if ( file_exists( $new_template ) ) {
                    return $new_template ;
                }
            }
        }
        else if(is_shop()){
            $new_template = plugin_dir_path( __FILE__ ) . 'woocommerce/archive-product.php';
                if ( file_exists( $new_template ) ) {
                    return $new_template ;
                }
        }
            
            return $template;
    }

    function wpg_body_classes( $classes ){
        if ( is_tax( 'product_cat') ) {
            $term = get_term(get_queried_object_id(), 'product_cat');
            // Check if parent has a term
            $ancestors = get_ancestors( $term -> term_id, 'product_cat' ) ;
            if( !empty( $ancestors ) ){
                $classes[] = 'wpg-sub-category-page';
                wp_dequeue_script( 'medigroup-mikado-smooth-page-scroll' );
            }
            else{
                $classes[] = 'wpg-category-page';
                wp_dequeue_script( 'medigroup-mikado-smooth-page-scroll' );
            }
        }
        if( is_shop()){
            $classes[] = 'wpg-shop-page';
            wp_dequeue_script( 'medigroup-mikado-smooth-page-scroll' );
        }
            
            return $classes;
    }

    function wpg_default_settings(){
        // Default settings
        include_once(WPG_DIR . 'inc/wpg_default_settings.php');
    }

    function wpg_handle_load_more(){
        // Handling loadmore button function ajax
        include_once(WPG_DIR . 'inc/wpg_handle_loadmore.php');
    }

    function wpg_filter_action(){
        // Handle filter action
        include_once(WPG_DIR . 'inc/wpg_filter_action.php');
    }

    function wpg_filter_action_cat(){
        // Handle filter action
        include_once(WPG_DIR . 'inc/wpg_filter_action_cat.php');
    }

    function wpg_filter_action_subcat(){
        // Handle filter action
        include_once(WPG_DIR . 'inc/wpg_filter_action_subcat.php');
    }

    function wpg_menu_page_settings(){
        //Add Menu Page
        include_once(WPG_DIR . 'inc/wpg_plugin_settings.php');
    }

    function wpg_save_settings(){
        // Save Plugin Settings
        include_once(WPG_DIR . 'inc/wpg_save_settings.php');
    }
    
    
    function wpg_settings_html(){
        // Render HTML 
        include_once(WPG_DIR . 'inc/wpg_settings_html.php');
    }

    public static function wpg_include_acf(){
        // Include ACF
        include_once( WPG_DIR . 'inc/wpg_include_acf.php' );

    }
 }


?>