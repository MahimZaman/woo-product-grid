<?php
// Hardwork has no alternative.
?>