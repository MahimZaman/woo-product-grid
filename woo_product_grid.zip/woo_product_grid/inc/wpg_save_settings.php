<?php
check_admin_referer( 'wpg-settings-nonce' );
update_option( 'wpg_post_perpage', $_POST['wpg_post_perpage'] );
update_option( 'wpg_post_perpage_mb', $_POST['wpg_post_perpage_mb'] );
update_option( 'wpg_progress_bar_color', $_POST['wpg_progress_bar_color'] );
update_option( 'wpg_line_color', $_POST['wpg_line_color'] );
update_option( 'wpg_loadmore_text', sanitize_text_field( $_POST['wpg_loadmore_text'] ) );
update_option( 'wpg_image_height', $_POST['wpg_image_height'] );
update_option( 'wpg_container_width', $_POST['wpg_container_width'] );
// Shop page settings
update_option( 'wpg_shop_title', sanitize_text_field( $_POST['wpg_shop_title'] ) );
update_option( 'wpg_shop_desc',  $_POST['wpg_shop_desc']  );
// Shop Settings >> Slider Code 
update_option( 'wpg_shop_slider',  $_POST['wpg_shop_slider'] );
wp_redirect( add_query_arg( 'settings-updated', 'true', $_POST['_wp_http_referer'] ) );
exit;
?>