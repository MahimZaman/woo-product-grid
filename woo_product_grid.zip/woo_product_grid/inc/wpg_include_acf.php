<?php
    // Define path and URL to the ACF plugin.
    define( 'WPG_ACF_PATH', WPG_DIR . 'inc/acf/' );
    define( 'WPG_ACF_URL', WPG_URL . 'inc/acf/' );

    // Include the ACF plugin.
    include_once( WPG_ACF_PATH . 'acf.php' );

    // Customize the url setting to fix incorrect asset URLs.
    add_filter('acf/settings/url', 'wpg_acf_settings_url');
    function wpg_acf_settings_url( $url ) {
        return WPG_ACF_URL;
    }

    // (Optional) Hide the ACF admin menu item.
    add_filter('acf/settings/show_admin', '__return_true');

    // When including the PRO plugin, hide the ACF Updates menu
    add_filter('acf/settings/show_updates', '__return_false', 100);

    // Adding custom Field 
    function wpg_add_custom_field(){

        acf_add_local_field_group(array(
            'key' => 'wpg_product_extras',
            'title' => 'Product Extras',
            'fields' => array(
                array(
                    'key' => 'wpg_product_name_extra',
                    'label' => 'Product Name Extra',
                    'name' => 'wpg_product_name_extra',
                    'type' => 'text',
                    'wrapper' => array(
                        'width' => '100%',
                    )
                    ),
                array(
                    'key' => 'wpg_product_btn_text',
                    'label' => 'Product Button Text',
                    'name' => 'wpg_product_btn_text',
                    'type' => 'text',
                    'wrapper' => array(
                        'width' => '100%',
                    )
                ),
                array(
                    'key' => 'wpg_product_text_extra',
                    'label' => 'Product Text Extra',
                    'name' => 'wpg_product_text_extra',
                    'type' => 'textarea',
                    'maxlength' => '150',
                    'wrapper' => array(
                        'width' => '100%',
                    )                    
                ),
                array(
                    'key' => 'wpg_product_img_extra',
                    'label' => 'Product Image Extra',
                    'name' => 'wpg_product_img_extra',
                    'type' => 'image',
                    'return_format' => 'array',
                    'wrapper' => array(
                        'width' => '100%',
                    ),
                ),
                array(
                    'key' => 'wpg_post_position',
                    'label' => 'Post Position in Grid',
                    'name' => 'wpg_post_position',
                    'type' => 'number',
                    'wrapper' => array(
                        'width' => '100%',
                    ),

                )                
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'post_type',
                        'operator' => '==',
                        'value' => 'product'
                    ),
                ),
            ),
            'position' => 'side',
        ));

        $arg = array(
            'post_type' => 'product',
            'posts_per_page' => -1
        );

        $query = new WP_Query($arg);

        if($query -> have_posts()){
            while($query -> have_posts()){
                $query -> the_post();
                if( !isset(get_post_meta( get_the_ID(), 'wpg_post_position' )[0]) ){
                    update_post_meta(get_the_ID(), 'wpg_post_position', '1000000000', '');
                }
            }
        }
   
    }

    add_action('acf/init', 'wpg_add_custom_field');

    function wpg_category_fields(){
        // Field group to product category        

        acf_add_local_field_group(array(
            'key' => 'wpg_category_slider',
            'title' => 'Category Slider',
            'fields' => array(
                array(
                    'key' => 'wpg_slider_shortcode',
                    'label' => 'Rev Slider Shortcode',
                    'name' => 'wpg_slider_shortcode',
                    'type' => 'text',
                    'wrapper' => array(
                        'width' => '100%'
                    ),
                ),                
            ),
            'location' => array(
                array(
                    array(
                        'param' => 'taxonomy',
                        'operator' => '==',
                        'value' => 'product_cat'
                    ),
                ),
            ),
        ));
    }

    add_action('acf/init', 'wpg_category_fields');

    
?>