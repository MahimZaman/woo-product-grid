<div class="wrap">
    <h2 class="wpg_admin_title">
        Woo Product Grid
    </h2>
    <form action="admin-post.php" method="post" class="d-flex flex-column w-25">
        <?php wp_nonce_field('wpg-settings-nonce');?>
        <input type="hidden" name="action" value="wpg_plugin_action">
        <label for="wpg_post_perpage">Posts per page: <i class="fa-solid fa-desktop"></i></label>
        <input type="number" class="form-control" name="wpg_post_perpage" id="wpg_post_perpage"
            value="<?php echo get_option('wpg_post_perpage')?>">

        <label for="wpg_post_perpage_mb">Posts per page (Mobile - Tablet): <i
                class="fa-solid fa-mobile-screen-button"></i> / <i class="fa-solid fa-tablet"></i></label>
        <input type="number" class="form-control" name="wpg_post_perpage_mb" id="wpg_post_perpage_mb"
            value="<?php echo get_option('wpg_post_perpage_mb')?>">


        <label for="wpg_progress_bar_color">Loadmore progress bar:</label>
        <input type="color" class="form-control" name="wpg_progress_bar_color" id="wpg_progress_bar_color"
            value="<?php echo get_option('wpg_progress_bar_color')?>">
        <label for="wpg_line_color">Separator Color:</label>
        <input type="color" class="form-control" name="wpg_line_color" id="wpg_line_color"
            value="<?php echo get_option('wpg_line_color')?>">
        <label for="wpg_loadmore_text">Load More Text:</label>
        <input type="text" class="form-control" name="wpg_loadmore_text" id="wpg_loadmore_text"
            value="<?php echo get_option('wpg_loadmore_text')?>">

        <div class="wpg_image_height">
            <label for="wpg_image_height">Product Grid Image Height (px)</label>
            <input type="number" class="form-control" id="wpg_image_height" name="wpg_image_height"
                value="<?php echo get_option('wpg_image_height');?>">
        </div>

        <div class="wpg_container_width">
            <label for="wpg_container_width">Container Width (px)</label>
            <input type="number" class="form-control" name="wpg_container_width" id="wpg_container_width"
                value="<?php echo get_option('wpg_container_width');?>">
        </div>

        <div class="wpg_shop_settings bg-light">
            <h2 class="wpg_shop_settings_title">
                Shop Settings
            </h2>
            <div class="wpg_shop_slider_settings">
                <?php 
                    if(class_exists('RevSlider')):
                    $slider = new RevSlider();
                    $slider_arr = $slider -> getArrSliders();

                    if(!$slider_arr){
                        echo '<span>Activate Revolution Slider to get the option to select</span>';
                    }
                ?>
                <label class="d-block" for="wpg_shop_slider">Shop Rev Slider Shortcode:</label>
                <select name="wpg_shop_slider" class="form-select w-100" id="wpg_shop_slider"
                    value='<?php echo get_option('wpg_shop_slider');?>'>
                    <option value=""><?php echo __('Select a slider', 'wpg-plugin');?></option>
                    <?php foreach($slider_arr as $slider):
                        $selected = $slider -> getAlias() == get_option('wpg_shop_slider') ? 'selected' : '';
                        ?>
                    <option value='<?php echo $slider -> getAlias()?>' <?php echo $selected ;?>>
                        <?php echo $slider -> getTitle();?></option>
                    <?php endforeach;?>
                </select>
                <?php
                    endif;
                ?>
            </div>
            <div class="wpg_content_settings">
                <label class="d-block" for="wpg_shop_title">Shop Title:</label>
                <input type="text" class="form-control" name="wpg_shop_title" id="wpg_shop_title"
                    value="<?php echo get_option('wpg_shop_title');?>">
                <label class="d-block" for="wpg_shop_desc">Shop Description:</label>
                <textarea name="wpg_shop_desc" class="form-control" id="wpg_shop_desc" cols="30"
                    rows="8"><?php echo get_option('wpg_shop_desc');?></textarea>
            </div>

        </div>
        <?php submit_button();?>
    </form>
</div>