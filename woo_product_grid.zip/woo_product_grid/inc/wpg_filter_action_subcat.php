<?php

    $taxArr = $_POST['terms'];
    $parent = $_POST['parent'];
    $pageSub = $_POST['page_sub_id'];


    if(wp_is_mobile()){
        $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
    }
    elseif(wp_is_mobile() && preg_match( '/iPad/', $_SERVER['HTTP_USER_AGENT'] )){
        $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
    }
    else{
        $wpg_posts_per_page = get_option('wpg_post_perpage');
    }
    $wpg_loadmore_text = get_option('wpg_loadmore_text');
    if(function_exists('icl_register_string')){
        $translate = 'icl_t';
    }
    else{
        $translate = '__';
    }

    $wpg_subcat_arr = get_term_children( $parent, 'product_cat' );

    $wpg_filtered_sub = [];

    if($taxArr != []){
        $wpg_filtered_sub = $taxArr ;        
    }
    else{
        $index = array_search($pageSub, $wpg_subcat_arr);
        if($index !== false){
            array_splice($wpg_subcat_arr, $index, 1) ;
            $wpg_filtered_sub = $wpg_subcat_arr ;
        }
        else{
            $wpg_filtered_sub = $wpg_subcat_arr ; 
        }
    }


?>

<?php foreach($wpg_filtered_sub as $id):

        $wpg_subcat_detail = get_term( $id , 'product_cat' );
        $arg = array(
            'post_type' => 'product',
            'posts_per_page' => $wpg_posts_per_page,
            'tax_query' => array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $id,
                    'include_children' => true
                ),
            ),
            'meta_key' => 'wpg_post_position',
            'orderby' => array(
                'meta_value_num' => 'ASC',
                'date' => 'ASC'
            ), 
        );
        
        $query = new WP_Query( $arg );
        
     if( $query -> have_posts() ):
        ?>
<div class="container position-relative pt-3 pt-lg-3 wpg_query_grid" data-cat_id=<?php echo $id;?>
    data-total_posts="<?php echo $query -> found_posts; ?>" data-total_pages="<?php echo $query -> max_num_pages ?>">

    <div class="row">
        <div class="col-12">
            <h3 class="wpg_subcat_title">
                <?php echo $wpg_subcat_detail -> name ;?>
            </h3>
            <div class="wpg_separator"></div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 d-flex flex-wrap wpg_product_items">
            <?php 
                if($query -> have_posts()):
                    while($query -> have_posts()):
                        $query-> the_post();
                        $product = wc_get_product( get_the_ID() );
                        $default_img = wp_get_attachment_url( $product -> get_image_id() ) ;
                        $img_extra = get_field('wpg_product_img_extra');
                        $name_extra = get_field('wpg_product_name_extra');
                        $btn_text = get_field('wpg_product_btn_text');
                        $text_extra = get_field('wpg_product_text_extra');
            ?>
            <div class="card mb-4 wpg_product_item px-0">
                <a href="<?php echo the_permalink();?>" class="wpg_card_overlay"></a>
                <?php 
                    if(isset($img_extra['url'])):
                ?>
                <img src="<?php echo $img_extra['url'];?>" class="card-img-top" alt="<?php echo $img_extra['alt'];?>">
                <?php
                    else:
                ?>
                <img src="<?php echo $default_img;?>" class="card-img-top" alt="<?php echo the_title();?>">
                <?php
                    endif;
                ?>

                <div class="card-body text-center d-flex flex-column justify-content-between px-0">
                    <div class="card-content">
                        <?php
                        if($name_extra != ''):
                    ?>
                        <h5 class="card-title  px-3"><?php echo $translate($name_extra, 'wpg-plugin');?></h5>
                        <?php
                        else:
                    ?>
                        <p class="card-title px-3"><?php echo $translate($product -> get_name(), 'wpg-plugin');?>
                        </p>
                        <?php
                        endif;
                    ?>
                        <?php 
                        if($text_extra != ''):
                    ?>
                        <p class="card-text px-3"><?php echo $translate($text_extra, 'wpg-plugin');?></p>
                        <?php 
                        else:
                    ?>
                        <span class="d-block card-text px-3">
                            <?php echo do_shortcode($product -> get_short_description());?>
                        </span>
                        <?php
                        endif;
                    ?>
                    </div>
                    <div class="card-footer text-center">
                        <a href="<?php echo the_permalink();?>" class="btn btn-primary stretched-link mt-2">
                            <?php if($btn_text != ''):
                            echo $btn_text;
                        else:
                            echo $translate('Visa produkt', 'wpg-plugin');
                        endif;
                        ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php
                endwhile;
                wp_reset_postdata();
            else:
                echo '<p class="">No posts found</p>';
            endif;
            ?>
        </div>
    </div>
</div>
<div class="container">
    <div class="row align-items-center justify-content-center">
        <div class="wpg_load_more d-flex align-items-center justify-content-center flex-column">
            <div class="wpg_post_count d-flex align-items-center justify-content-center flex-column">
                <div class="wpg_loader" style='display: none'></div>
                <span class="wpg_counter"><?php echo $translate('Showing', 'wpg-plugin')?> <span
                        class="wpg_post_showing"><?php echo $query -> post_count;?></span>
                    <?php echo $translate('of', 'wpg-plugin')?> <span
                        class="wpg_available_post"><?php echo $query -> found_posts?></span>
                    <?php echo $translate('results', 'wpg-plugin')?></span>
                <span class="wpg_progress_bar">
                    <?php 
                            if(intval($query -> found_posts) <= 0){
                                $wpg_loadbar_width = 0;
                            }
                            else{
                                $wpg_loadbar_width = (intval($wpg_posts_per_page) / intval($query -> found_posts)) * 100 . '%';
                            }
                        ?>
                    <span class="wpg_load_bar" style="width: <?php echo $wpg_loadbar_width ;?> "></span>
                </span>
            </div>
            <?php
                   if(intval($query -> found_posts) <= intval($wpg_posts_per_page)){
                     $display = 'display: none';
                   }
                   else{
                     $display = '';
                   }
                ?>
            <button class="px-5 btn-lg btn btn-primary wpg_loadmore_btn" data-page_no="1"
                style="<?php echo $display;?>"><?php echo $wpg_loadmore_text == '' ? $translate('Load More', 'wpg-plugin'): $translate($wpg_loadmore_text, 'wpg-plugin');?></button>
        </div>
    </div>
</div>
<?php 
endif;
endforeach;
die();
?>