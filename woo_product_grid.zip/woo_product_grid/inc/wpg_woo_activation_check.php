<?php
 if( !in_array('woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option('active_plugins') )) ){

    add_action('admin_notices', function(){
        echo '<div class="notice notice-error">
            <p>Install & Activate Woocommerce first to use Woo Product Grid</p>
        </div>';
    });

 }

 else{
    $wpg = new Woo_Product_Grid();    
    Woo_Product_Grid::wpg_include_acf();
 }

?>