<?php
$wpg_line_color = get_option('wpg_line_color');
$wpg_progress_bar_color = get_option('wpg_progress_bar_color');
$wpg_image_height = get_option('wpg_image_height');
$wpg_container_width = get_option('wpg_container_width');
?>

<style>
.wpg_separator {
    background: <?php echo $wpg_line_color;
    ?>
}

.wpg_load_bar {
    background: <?php echo $wpg_progress_bar_color;
    ?>
}

.wpg_loader {
    border-top: 3px solid <?php echo $wpg_progress_bar_color;
    ?>;
    border-bottom: 3px solid <?php echo $wpg_progress_bar_color;
    ?>;
}

.wpg_product_item img {
    max-height: <?php echo $wpg_image_height . 'px';
    ?>;
    height: <?php echo $wpg_image_height . 'px';
    ?>;
    object-fit: cover;
}

.wpg-category-page .container,
.wpg-sub-category-page .container,
.wpg-shop-page .container {
    max-width: <?php echo $wpg_container_width . 'px';
    ?> !important;
}
</style>