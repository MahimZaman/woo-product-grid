<?php
    if(get_option('wpg_post_perpage') == ''){
        update_option('wpg_post_perpage', '12');
    }

    if(get_option('wpg_post_perpage_mb') == ''){
        update_option('wpg_post_perpage_mb', '6');
    }

    if(get_option('wpg_loadmore_text') == ''){
        update_option('wpg_loadmore_text', 'Load More');
    }

    if(get_option('wpg_progress_bar_color') == ''){
        update_option('wpg_progress_bar_color', '#0d6efd');
    }

    if(get_option('wpg_line_color') == ''){
        update_option('wpg_line_color', '#0d6efd');
    }

    if(get_option('wpg_image_height') == ''){
        update_option('wpg_image_height', '300');
    }

    if(get_option('wpg_container_width') == ''){
        update_option('wpg_container_width', '1100');
    }

    if(get_option('wpg_shop_title') == ''){
        update_option('wpg_shop_title', 'Product');
    }

    if(get_option('wpg_shop_desc') == ''){
        update_option('wpg_shop_desc', 'Add shop page description here...');
    }

?>