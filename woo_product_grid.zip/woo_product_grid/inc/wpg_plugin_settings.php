<?php
add_menu_page( 
    'Woo Product Grid',
    'Woo Product Grid', 
    'manage_options', 
    'wpg-settings', 
    array($this, 'wpg_settings_html'), 
    'dashicons-screenoptions',
    99
);  
?>