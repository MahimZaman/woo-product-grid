<?php 
$total_pages = $_POST['total_pages'];
$total_posts = $_POST['total_posts'];
$paged = $_POST['page'];
$cat_id = $_POST['cat_id'];

if(function_exists('icl_register_string')){
    $translate = 'icl_t';
}
else{
    $translate = '__';
}

if(wp_is_mobile()){
    $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
}
elseif(wp_is_mobile() && preg_match( '/iPad/', $_SERVER['HTTP_USER_AGENT'] )){
    $wpg_posts_per_page = get_option('wpg_post_perpage_mb');
}
else{
    $wpg_posts_per_page = get_option('wpg_post_perpage');
}



$arg = array(
'post_type' => 'product',
'posts_per_page' => $wpg_posts_per_page,
'paged' => $paged,
'tax_query' => array(
array(
'taxonomy' => 'product_cat',
'field' => 'term_id',
'terms' => $cat_id,
'include_children' => true
),
),
'meta_key' => 'wpg_post_position',
'orderby' => array(
    'meta_value_num' => 'ASC',
    'date' => 'ASC'
), 
);

$query = new WP_Query( $arg );



while($query -> have_posts()):
$query -> the_post();
$product = wc_get_product( get_the_ID() );
$default_img = wp_get_attachment_url( $product -> get_image_id() ) ;
$img_extra = get_field('wpg_product_img_extra');
$name_extra = get_field('wpg_product_name_extra');
$btn_text = get_field('wpg_product_btn_text');
$text_extra = get_field('wpg_product_text_extra');
?>

<div class="card mb-4 wpg_product_item px-0">
    <a href="<?php echo the_permalink();?>" class="wpg_card_overlay"></a>
    <?php 
                    if(isset($img_extra['url'])):
                ?>
    <img src="<?php echo $img_extra['url'];?>" class="card-img-top" alt="<?php echo $img_extra['alt'];?>">
    <?php
                    else:
                ?>
    <img src="<?php echo $default_img;?>" class="card-img-top" alt="<?php echo the_title();?>">
    <?php
                    endif;
                ?>

    <div class="card-body text-center px-0 d-flex flex-column justify-content-between">
        <div class="card-content">
            <?php
                        if($name_extra != ''):
                    ?>
            <h5 class="card-title  px-3"><?php echo $translate($name_extra, 'wpg-plugin');?></h5>
            <?php
                        else:
                    ?>
            <p class="card-title px-3"><?php echo $translate($product -> get_name(), 'wpg-plugin');?></p>
            <?php
                        endif;
                    ?>
            <?php 
                        if($text_extra != ''):
                    ?>
            <p class="card-text px-3"><?php echo $translate($text_extra, 'wpg-plugin');?></p>
            <?php 
                        else:
                    ?>
            <span class="d-block card-text px-3">
                <?php echo do_shortcode($product -> get_short_description());?>
            </span>
            <?php
                        endif;
                    ?>
        </div>
        <div class="card-footer text-center">
            <a href="<?php echo the_permalink();?>" class="btn btn-primary stretched-link mt-2">
                <?php if($btn_text != ''):
                            echo $btn_text;
                        else:
                            echo $translate('Visa produkt', 'wpg-plugin');
                        endif;
                        ?>
            </a>
        </div>
    </div>
</div>


<?php
    endwhile;
    wp_reset_postdata();
    die();